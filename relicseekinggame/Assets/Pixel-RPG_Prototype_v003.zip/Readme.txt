README

Thank you for downloading <3

You can find all of my assets over here: https://snoblin.itch.io

Please take the time to rate them and give me feedback.

If you have any questions, feel free to contact me with a comment on itch.


LICENSE

YOU CAN:
1. USE THESE ASSETS IN COMMERCIAL OR NON-COMMERCIAL PROJECTS.
2. EDIT THESE ASSETS.

YOU CAN NOT:
1. REDISTRIBUTE THESE ASSETS.
2. EDIT AND REDISTRIBUTE THESE ASSETS.